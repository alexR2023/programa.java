# Source Generated with Decompyle++
# File: archivos.pyc (Python 3.9)

from tkinter import *
from tkinter import filedialog
from tkinter import messagebox

class App(Tk):
    
    def __init__(self = None):
        super().__init__()
        self.geometry('400x300')
        self.title('Manipula archivos')
        self.barra_de_menus = Menu(self)
        self.config(menu=self.barra_de_menus)
        self.menu1 = Menu(self.barra_de_menus, tearoff = 0)
        self.menu1.add_command(label = 'Nuevo', command = self.nuevo)
        self.menu1.add_command(label = 'Abrir', command = self.abrir)
        self.menu1.add_command(label = 'Guardar como', command = self.guardar)
        self.menu1.add_separator()
        self.menu1.add_command(label = 'Cerrar', command = self.quit)
        self.menu2 = Menu(self.barra_de_menus, tearoff = 0)
        self.menu2.add_command(label = 'Version', command = self.version)
        self.menu2.add_command(label = 'Sobre mi', command = self.sobre)
        self.barra_de_menus.add_cascade(label = 'Archivo', menu = self.menu1)
        self.barra_de_menus.add_cascade(label = 'Ayuda', menu = self.menu2)
        self.scrollv = Scrollbar(self)
        self.scrollv.pack(side = RIGHT, fill = 'y')
        self.scrollh = Scrollbar(self, orient = HORIZONTAL)
        self.scrollh.pack(side = BOTTOM, fill = 'x')
        self.texto = Text(self, height = 500, width = 350, yscrollcommand = self.scrollv.set, xscrollcommand = self.scrollh.set, wrap = NONE)
        self.texto.pack(fill = BOTH, expand = 0)

    
    def nuevo(self):
        self.texto.delete(1, END)

    
    def abrir(self):
        selectordearchivo = filedialog.askopenfile((('text files', '.txt'), ('All files', '.')), *('filetypes',))
        if selectordearchivo is not None:
            archivo = open(selectordearchivo.name, 'r', 'utf-8', **('encoding',))
            self.texto.delete(1, END)
            self.texto.insert(END, archivo.read())
            archivo.close()

    
    def guardar(self):
        selectordearchivo = filedialog.asksaveasfile((('text files', '.txt'), ('All files', '.')), '.txt', 'w', *('filetypes', 'defaultextension', 'mode'))
        if selectordearchivo is not None:
            archivo = open(selectordearchivo.name, 'w', 'utf-8', **('encoding',))
            archivo.write(self.texto.get(1, END))
            archivo.close()

    
    def sobre(self):
        messagebox.showinfo(title = 'Sobre mi', message = 'Creado por: RF202204')

    
    def version(self):
        messagebox.showinfo(title = 'Version', message = 'Version: 2.0')

    __classcell__ = None

if __name__ == '__main__':
    app = App()
    app.mainloop()
