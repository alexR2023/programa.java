[] = c
y = []
for [] in x:
    BLOCK
[] = []
