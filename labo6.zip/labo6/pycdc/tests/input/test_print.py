print 1, 2, 3, 4, 5
a = b + 5
print 1, 2, 3, 4, 5
print 1, 2, 3, 4, 5
print
print
print 1, 2, 3, 4, 5
print
