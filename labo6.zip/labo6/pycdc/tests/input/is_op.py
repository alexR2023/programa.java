a = 10
b = 10

if a is b:
    pass

if a is not b:
    pass

