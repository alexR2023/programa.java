# Source Generated with Decompyle++
# File: login.pyc (Python 3.9)

usuario = input('Ingrese usuario: ')
passwd = input('Ingrese contraseña: ')
if usuario == 'RF202204' and passwd == 'alex':
    print('Credenciales Validas')
else:
    print('NO VALIDO')
